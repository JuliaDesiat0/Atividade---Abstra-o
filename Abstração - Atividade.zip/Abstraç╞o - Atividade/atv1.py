class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade

pessoa1 = Pessoa("Julia", 16)
pessoa2 = Pessoa("Artur", 18)
