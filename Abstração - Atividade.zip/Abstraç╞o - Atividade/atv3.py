class ContaBancaria:
    def __init__(self, titular, numero, saldo=0):
        self.titular = titular
        self.numero = numero
        self.saldo = saldo

    def depositar(self, valor):
        self.saldo += valor

    def sacar(self, valor):
        if valor <= self.saldo:
            self.saldo -= valor
        else:
            print("Saldo insuficiente para saque.")

    def exibir_saldo(self):
        print(f"Saldo atual da conta de {self.titular}: R${self.saldo}")

conta1 = ContaBancaria("Julia", "12345")
conta2 = ContaBancaria("Artur", "67890", 1000)

conta1.depositar(500)
conta2.sacar(200)

conta1.exibir_saldo()
conta2.exibir_saldo()
